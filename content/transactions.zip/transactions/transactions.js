$(document).ready(function() {
    setContentGrnCard() 
    // el.find('select').trigger('change')
    // $("#rpp-table-events").trigger('change')
  })
  
  var tableGrnColumn = {
    'orderId' : 'Order Id', 'date' : 'Date', 'eventName' : 'Event Name', 'customer' : 'Customer', 
    'location' : 'Location', 'sold' : 'Sold Ticket', 'available' : 'Available', 'refund' : 'Refund', 
    'totalRevenue' : 'Total Revenue', 'status' : 'Status' 
  }
  
  var filterGrnCount = {'all' : 'All', 'available' : 'Available', 'sold' : 'Sold', 'refunded' : 'Refunded', 'canceled' : 'Canceled'}
  
  // SET CONTENT FOR EVENTS CARD --ir
  function setContentGrnCard() {
    // SET HEADER AND FOOTER FOR TABLE EVENTS --ir
    setBasicHeaderFooterTable($('#myContent #table-grn thead'), tableGrnColumn, 'head')
    setBasicHeaderFooterTable($('#myContent #table-grn tfoot'), tableGrnColumn, 'foot')
    
    // SET FILTER, SEARCH AND ROW PER PAGE --ir
    setButtonFilterCount($('#card-table-grn .filter-count-row'), filterGrnCount, "event")
    setSearch($("#card-table-grn .search-bar"), "table-grn")
    setRowsPerPage($("#card-table-grn .row-page"), "table-grn")
  }
  
  // SET CONTENT TABLE BODY FOR TABLE EVENTS --ir
  function setTableEvents(filterCount) {
    tbodyEvent = $('#myContent #table-grn tbody'); 
    $.ajax({
      async   : false,
      success   : function() {
        // LOAD DATA FOR TABLE BODY CONTENT --ir
        $.getJSON(urlOrigin + "/data/table-grn.json", function(data) {
          // FILTER DATA BASED ON SELECTED BUttON ROW COUnt --ir
          dataGrn = data['data-grn']
          if(filterCount != "all") var dataGrn = dataGrn.filter(a => a.status == filterCount);
          $('#card-table-grn .filter-count-row span').empty().append(dataGrn.length + " Total GRN")
          
          $.each(dataGrn, function(i, rowData) {
            tbodyGrn.append('<tr class="eventRow-' + i + '"></tr>');
            $.each(rowData, function(key, value) {
              if(key == "available") value = thousandToK(value)
              tbodyGrn.find('tr:last').append('<td class="col-' + key + '">' + value + '</td>')
            })
          })
  
          // SET PAGINATION BASED ON SELECTED ROWS PER PAGE OPTION --ir
          $("#rpp-table-grn").trigger('change')
        }) 
      },beforeSend  : function() {
        tbodyEvent.empty();
        $('#table-grn').hide()
      },complete  : function() {
        $('#table-grn').show()
      }
    })
    
  
  }